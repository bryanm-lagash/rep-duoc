USE OnTour

--Insert de los tipos de colegio
INSERT [dbo].[tipcole] ([idtipo], [nombre]) VALUES (1, 'Municipal')
INSERT [dbo].[tipcole] ([idtipo], [nombre]) VALUES (2, 'Particular')

--Insert de los destinos
INSERT [dbo].[destino] ([iddestino], [nombre], [ciudaddestino]) VALUES (1, 'Chile', 'Santiago')
INSERT [dbo].[destino] ([iddestino], [nombre], [ciudaddestino]) VALUES (2, 'Peru', 'Lima')
INSERT [dbo].[destino] ([iddestino], [nombre], [ciudaddestino]) VALUES (3, 'Brazil', 'Rio de Janeiro')
INSERT [dbo].[destino] ([iddestino], [nombre], [ciudaddestino]) VALUES (4, 'Colombia', 'Bogot�')
INSERT [dbo].[destino] ([iddestino], [nombre], [ciudaddestino]) VALUES (5, 'Estados Unidos', 'Washington D.C.')
INSERT [dbo].[destino] ([iddestino], [nombre], [ciudaddestino]) VALUES (6, 'Espa�a', 'Madrid')

--Insert de los beneficios
INSERT [dbo].[beneficio] ([idbenefico], [nombre], [porcdescuento]) VALUES (1, 'Desc.por cantidad de personas', 15)
INSERT [dbo].[beneficio] ([idbenefico], [nombre], [porcdescuento]) VALUES (2, 'Desc.para colegio municipal', 25)
INSERT [dbo].[beneficio] ([idbenefico], [nombre], [porcdescuento]) VALUES (3, 'Desc.para colegio particular', 20)

--Insert de las actividades
INSERT [dbo].[actividad] ([idactividad], [nombre], [costo]) VALUES (1, 'Tour Nocturno', 25000)
INSERT [dbo].[actividad] ([idactividad], [nombre], [costo]) VALUES (2, 'Visita a parque tematico', 30000)
INSERT [dbo].[actividad] ([idactividad], [nombre], [costo]) VALUES (3, 'Visita a museo', 40000)

--Insert de la modalidad de los aportes
INSERT [dbo].[modaporte] ([idmod], [nombre]) VALUES (1, 'Apoderados')
INSERT [dbo].[modaporte] ([idmod], [nombre]) VALUES (2, 'Apoderados y Curso')

--Insert de los tipos de actividades
INSERT [dbo].[tipactividad] ([idtipoact], [nombre], [modaporte_idmod]) VALUES (1, 'No aplica', 1)
INSERT [dbo].[tipactividad] ([idtipoact], [nombre], [modaporte_idmod]) VALUES (2, 'Fiestas y Rifas', 2)

--Insert de los tipos de usuarios
INSERT [dbo].[tipcuenta] ([idtipocta], [nombre]) VALUES (1, 'Apoderado')
INSERT [dbo].[tipcuenta] ([idtipocta], [nombre]) VALUES (2, 'Adm. de Sistema')
INSERT [dbo].[tipcuenta] ([idtipocta], [nombre]) VALUES (3, 'Ejecutivo de Ventas')
INSERT [dbo].[tipcuenta] ([idtipocta], [nombre]) VALUES (4, 'Due�o')

--Insert de las tasa de interes por dias de atraso
INSERT [dbo].[tasa_interes] ([idinteres], [diasini], [diasterm], [porcmulta]) VALUES (1, 1, 7, 10)
INSERT [dbo].[tasa_interes] ([idinteres], [diasini], [diasterm], [porcmulta]) VALUES (2, 8, 15, 20)
INSERT [dbo].[tasa_interes] ([idinteres], [diasini], [diasterm], [porcmulta]) VALUES (3, 16, 30, 30)