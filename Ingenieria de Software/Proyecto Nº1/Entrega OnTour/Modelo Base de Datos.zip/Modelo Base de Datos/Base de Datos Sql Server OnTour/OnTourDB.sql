USE OnTour 

CREATE TABLE actividad (
    idactividad   [int] NOT NULL,
    nombre        [nvarchar](30) NOT NULL,
    costo         [int] NOT NULL
);

ALTER TABLE actividad ADD CONSTRAINT actividad_pk PRIMARY KEY ( idactividad );


CREATE TABLE adm_sis (
    rutadmsis   [nvarchar](11) NOT NULL,
    nombre      [nvarchar](30) NOT NULL,
    apaterno    [nvarchar](30) NOT NULL,
    amaterno    [nvarchar](30) NOT NULL,
    direccion   [nvarchar](30) NOT NULL
);

ALTER TABLE adm_sis ADD CONSTRAINT adm_sis_pk PRIMARY KEY ( rutadmsis );

CREATE TABLE alumno (
    rutalumno                  [nvarchar](11) NOT NULL,
    nombre                     [nvarchar](50) NOT NULL,
    apaterno                   [nvarchar](50) NOT NULL,
    amaterno                   [nvarchar](50) NOT NULL,
    direccion                  [nvarchar](70) NOT NULL,
    curso_idcurso              [nvarchar](10) NOT NULL,
    curso_colegio_codcolegio   [nvarchar](10) NOT NULL,
    curso_colegio_idtipo       [int] NOT NULL,
    apoderado_rutapoderado     [nvarchar](11) NOT NULL
);

ALTER TABLE alumno
    ADD CONSTRAINT alumno_pk PRIMARY KEY ( rutalumno,
                                           curso_idcurso,
                                           curso_colegio_codcolegio,
                                           curso_colegio_idtipo,
                                           apoderado_rutapoderado );

CREATE TABLE apoderado (
    rutapoderado   [nvarchar](11) NOT NULL,
    nombre         [nvarchar](30) NOT NULL,
    apaterno       [nvarchar](30) NOT NULL,
    amaterno       [nvarchar](30) NOT NULL,
    direccion      [nvarchar](30) NOT NULL
);

ALTER TABLE apoderado ADD CONSTRAINT apoderado_pk PRIMARY KEY ( rutapoderado );

CREATE TABLE beneficio (
    idbenefico      [int] NOT NULL,
    nombre          [nvarchar](30) NOT NULL,
    porcdescuento   [int] NOT NULL
);

ALTER TABLE beneficio ADD CONSTRAINT beneficio_pk PRIMARY KEY ( idbenefico );

CREATE TABLE colegio (
    codcolegio       [nvarchar](10) NOT NULL,
    nombre           [nvarchar](50) NOT NULL,
    direccion        [nvarchar](50) NOT NULL,
    tipcole_idtipo   [int] NOT NULL
);

ALTER TABLE colegio ADD CONSTRAINT colegio_pk PRIMARY KEY ( codcolegio,
                                                            tipcole_idtipo );

CREATE TABLE contrato (
    numcontrato                    [int] NOT NULL,
    fechacreacion                  DATE NOT NULL,
    fechatermino                   DATE NOT NULL,
    destino                        [nvarchar](50) NOT NULL,
    duraciondias                   [int] NOT NULL,
    fechaini                       DATE NOT NULL,
    fechaterm                      DATE NOT NULL,
    curso_idcurso                  [nvarchar](10) NOT NULL,
    curso_colegio_codcolegio       [nvarchar](10) NOT NULL,
    ejecutivo_rutejecutivo         [nvarchar](11) NOT NULL,
    destino_iddestino              [int] NOT NULL,
    tipactividad_idtipoact         [int] NOT NULL,
    fechapagos                     [nvarchar](30) NOT NULL,
    costototseguros                [int] NOT NULL,
    costototactividades            [int] NOT NULL,
    porctotbeneficios              [int] NOT NULL,
    costoservicios                 [int] NOT NULL,
    meta                           [int] NOT NULL,
    tipactividad_modaporte_idmod   [int] NOT NULL,
    curso_colegio_idtipo           [int] NOT NULL
);

ALTER TABLE contrato
    ADD CONSTRAINT contrato_pk PRIMARY KEY ( numcontrato,
                                             curso_idcurso,
                                             curso_colegio_codcolegio,
                                             curso_colegio_idtipo,
                                             ejecutivo_rutejecutivo,
                                             destino_iddestino,
                                             tipactividad_idtipoact,
                                             tipactividad_modaporte_idmod );

CREATE TABLE cta_usuario (
    apoderado_rutapoderado   [nvarchar](11) NOT NULL,
    ejecutivo_rutejecutivo   [nvarchar](11) NOT NULL,
    tipcuenta_idtipocta      [int] NOT NULL,
    due�o_rutdue�o           [nvarchar](11) NOT NULL,
    adm_sis_rutadmsis        [nvarchar](11) NOT NULL,
    nombre                   [nvarchar](30) NOT NULL,
    contrase�a               [nvarchar](30) NOT NULL
);

ALTER TABLE cta_usuario
    ADD CONSTRAINT cta_usuario_pk PRIMARY KEY ( apoderado_rutapoderado,
                                                ejecutivo_rutejecutivo,
                                                tipcuenta_idtipocta,
                                                due�o_rutdue�o,
                                                adm_sis_rutadmsis );

CREATE TABLE curso (
    idcurso              [nvarchar](10) NOT NULL,
    numalumnos           [int] NOT NULL,
    colegio_codcolegio   [nvarchar](10) NOT NULL,
    colegio_idtipo       [int] NOT NULL
);

ALTER TABLE curso
    ADD CONSTRAINT curso_pk PRIMARY KEY ( idcurso,
                                          colegio_codcolegio,
                                          colegio_idtipo );

CREATE TABLE deposito (
    iddeposito                 [int] NOT NULL,
    fechadeposito              DATE NOT NULL,
    montodeposito              [int] NOT NULL,
    curso_idcurso              [nvarchar](10) NOT NULL,
    curso_colegio_codcolegio   [nvarchar](10) NOT NULL,
    curso_colegio_idtipo       [int] NOT NULL
);

ALTER TABLE deposito
    ADD CONSTRAINT deposito_pk PRIMARY KEY ( iddeposito,
                                             curso_idcurso,
                                             curso_colegio_codcolegio,
                                             curso_colegio_idtipo );

CREATE TABLE destino (
    iddestino       [int] NOT NULL,
    nombre          [nvarchar](30) NOT NULL,
    ciudaddestino   [nvarchar](30) NOT NULL
);

ALTER TABLE destino ADD CONSTRAINT destino_pk PRIMARY KEY ( iddestino );

CREATE TABLE detalle_actividad (
    cant_actividades        [int] NOT NULL,
    actividad_idactividad   [int] NOT NULL,
    contrato_numcontrato    [int] NOT NULL,
    contrato_idcurso        [nvarchar](10) NOT NULL,
    contrato_codcolegio     [nvarchar](10) NOT NULL,
    contrato_rutejecutivo   [nvarchar](11) NOT NULL,
    contrato_iddestino      [int] NOT NULL,
    contrato_idtipoact      [int] NOT NULL,
    contrato_idmod          [int] NOT NULL,
    contrato_idtipo         [int] NOT NULL
);

ALTER TABLE detalle_actividad
    ADD CONSTRAINT detalle_actividad_pk PRIMARY KEY ( actividad_idactividad,
                                                      contrato_numcontrato,
                                                      contrato_idcurso,
                                                      contrato_codcolegio,
                                                      contrato_idtipo,
                                                      contrato_rutejecutivo,
                                                      contrato_iddestino,
                                                      contrato_idtipoact,
                                                      contrato_idmod );


CREATE TABLE detalle_beneficio (
    cant_beneficios         [int] NOT NULL,
    beneficio_idbenefico    [int] NOT NULL,
    contrato_numcontrato    [int] NOT NULL,
    contrato_idcurso        [nvarchar](10) NOT NULL,
    contrato_codcolegio     [nvarchar](10) NOT NULL,
    contrato_rutejecutivo   [nvarchar](11) NOT NULL,
    contrato_iddestino      [int] NOT NULL,
    contrato_idtipoact      [int] NOT NULL,
    contrato_idmod          [int] NOT NULL,
    contrato_idtipo         [int] NOT NULL
);

ALTER TABLE detalle_beneficio
    ADD CONSTRAINT detalle_beneficio_pk PRIMARY KEY ( beneficio_idbenefico,
                                                      contrato_numcontrato,
                                                      contrato_idcurso,
                                                      contrato_codcolegio,
                                                      contrato_idtipo,
                                                      contrato_rutejecutivo,
                                                      contrato_iddestino,
                                                      contrato_idtipoact,
                                                      contrato_idmod );

CREATE TABLE detalle_seguro (
    cant_seguros            [int] NOT NULL,
    seguro_idseguro         [int] NOT NULL,
    seguro_empaseg_rutemp   [nvarchar](11) NOT NULL,
    contrato_numcontrato    [int] NOT NULL,
    contrato_idcurso        [nvarchar](10) NOT NULL,
    contrato_codcolegio     [nvarchar](10) NOT NULL,
    contrato_rutejecutivo   [nvarchar](11) NOT NULL,
    contrato_iddestino      [int] NOT NULL,
    contrato_idtipoact      [int] NOT NULL,
    contrato_idmod          [int] NOT NULL,
    contrato_idtipo         [int] NOT NULL
);

ALTER TABLE detalle_seguro
    ADD CONSTRAINT detalle_seguro_pk PRIMARY KEY ( seguro_idseguro,
                                                   seguro_empaseg_rutemp,
                                                   contrato_numcontrato,
                                                   contrato_idcurso,
                                                   contrato_codcolegio,
                                                   contrato_idtipo,
                                                   contrato_rutejecutivo,
                                                   contrato_iddestino,
                                                   contrato_idtipoact,
                                                   contrato_idmod );

CREATE TABLE due�o (
    rutdue�o    [nvarchar](11) NOT NULL,
    nombre      [nvarchar](30) NOT NULL,
    apaterno    [nvarchar](30) NOT NULL,
    amaterno    [nvarchar](30) NOT NULL,
    direccion   [nvarchar](30) NOT NULL
);

ALTER TABLE due�o ADD CONSTRAINT due�o_pk PRIMARY KEY ( rutdue�o );

CREATE TABLE ejecutivo (
    rutejecutivo   [nvarchar](11) NOT NULL,
    nombre         [nvarchar](50) NOT NULL,
    apaterno       [nvarchar](50) NOT NULL,
    amaterno       [nvarchar](50) NOT NULL,
    direccion      [nvarchar](30) NOT NULL
);

ALTER TABLE ejecutivo ADD CONSTRAINT ejecutivo_pk PRIMARY KEY ( rutejecutivo );

CREATE TABLE empaseg (
    rutemp      [nvarchar](11) NOT NULL,
    nombre      [nvarchar](30) NOT NULL,
    direccion   [nvarchar](30) NOT NULL,
    telefono    [int] NOT NULL
);

ALTER TABLE empaseg ADD CONSTRAINT empaseg_pk PRIMARY KEY ( rutemp );

CREATE TABLE modaporte (
    idmod    [int] NOT NULL,
    nombre   [nvarchar](20) NOT NULL
);

ALTER TABLE modaporte ADD CONSTRAINT modaporte_pk PRIMARY KEY ( idmod );

CREATE TABLE seguro (
    idseguro         [int] NOT NULL,
    nombre           [nvarchar](30) NOT NULL,
    descripcion      [nvarchar](30) NOT NULL,
    costo            [int] NOT NULL,
    empaseg_rutemp   [nvarchar](11) NOT NULL
);

ALTER TABLE seguro ADD CONSTRAINT seguro_pk PRIMARY KEY ( idseguro,
                                                          empaseg_rutemp );

CREATE TABLE tasa_interes (
    idinteres    [int] NOT NULL,
    diasini   [int] NOT NULL,
	diasterm   [int] NOT NULL,
    porcmulta    [int] NOT NULL
);

ALTER TABLE tasa_interes ADD CONSTRAINT tasa_interes_pk PRIMARY KEY ( idinteres );

CREATE TABLE tipactividad (
    idtipoact         [int] NOT NULL,
    nombre            [nvarchar](30) NOT NULL,
    modaporte_idmod   [int] NOT NULL
);

ALTER TABLE tipactividad ADD CONSTRAINT tipactividad_pk PRIMARY KEY ( idtipoact,
                                                                      modaporte_idmod );

CREATE TABLE tipcole (
    idtipo   [int] NOT NULL,
    nombre   [nvarchar](30) NOT NULL
);

ALTER TABLE tipcole ADD CONSTRAINT tipcole_pk PRIMARY KEY ( idtipo );

CREATE TABLE tipcuenta (
    idtipocta   [int] NOT NULL,
    nombre      [nvarchar](30) NOT NULL
);

ALTER TABLE tipcuenta ADD CONSTRAINT tipcuenta_pk PRIMARY KEY ( idtipocta );

ALTER TABLE alumno
    ADD CONSTRAINT alumno_apoderado_fk FOREIGN KEY ( apoderado_rutapoderado )
        REFERENCES apoderado ( rutapoderado );

ALTER TABLE alumno
    ADD CONSTRAINT alumno_curso_fk FOREIGN KEY ( curso_idcurso,
                                                 curso_colegio_codcolegio,
                                                 curso_colegio_idtipo )
        REFERENCES curso ( idcurso,
                           colegio_codcolegio,
                           colegio_idtipo );

ALTER TABLE colegio
    ADD CONSTRAINT colegio_tipcole_fk FOREIGN KEY ( tipcole_idtipo )
        REFERENCES tipcole ( idtipo );

ALTER TABLE contrato
    ADD CONSTRAINT contrato_curso_fk FOREIGN KEY ( curso_idcurso,
                                                   curso_colegio_codcolegio,
                                                   curso_colegio_idtipo )
        REFERENCES curso ( idcurso,
                           colegio_codcolegio,
                           colegio_idtipo );

ALTER TABLE contrato
    ADD CONSTRAINT contrato_destino_fk FOREIGN KEY ( destino_iddestino )
        REFERENCES destino ( iddestino );

ALTER TABLE contrato
    ADD CONSTRAINT contrato_ejecutivo_fk FOREIGN KEY ( ejecutivo_rutejecutivo )
        REFERENCES ejecutivo ( rutejecutivo );

ALTER TABLE contrato
    ADD CONSTRAINT contrato_tipactividad_fk FOREIGN KEY ( tipactividad_idtipoact,
                                                          tipactividad_modaporte_idmod )
        REFERENCES tipactividad ( idtipoact,
                                  modaporte_idmod );

ALTER TABLE cta_usuario
    ADD CONSTRAINT cta_usuario_adm_sis_fk FOREIGN KEY ( adm_sis_rutadmsis )
        REFERENCES adm_sis ( rutadmsis );

ALTER TABLE cta_usuario
    ADD CONSTRAINT cta_usuario_apoderado_fk FOREIGN KEY ( apoderado_rutapoderado )
        REFERENCES apoderado ( rutapoderado );

ALTER TABLE cta_usuario
    ADD CONSTRAINT cta_usuario_due�o_fk FOREIGN KEY ( due�o_rutdue�o )
        REFERENCES due�o ( rutdue�o );

ALTER TABLE cta_usuario
    ADD CONSTRAINT cta_usuario_ejecutivo_fk FOREIGN KEY ( ejecutivo_rutejecutivo )
        REFERENCES ejecutivo ( rutejecutivo );

ALTER TABLE cta_usuario
    ADD CONSTRAINT cta_usuario_tipcuenta_fk FOREIGN KEY ( tipcuenta_idtipocta )
        REFERENCES tipcuenta ( idtipocta );

ALTER TABLE curso
    ADD CONSTRAINT curso_colegio_fk FOREIGN KEY ( colegio_codcolegio,
                                                  colegio_idtipo )
        REFERENCES colegio ( codcolegio,
                             tipcole_idtipo );

ALTER TABLE deposito
    ADD CONSTRAINT deposito_curso_fk FOREIGN KEY ( curso_idcurso,
                                                   curso_colegio_codcolegio,
                                                   curso_colegio_idtipo )
        REFERENCES curso ( idcurso,
                           colegio_codcolegio,
                           colegio_idtipo );

ALTER TABLE detalle_actividad
    ADD CONSTRAINT detalle_actividad_actividad_fk FOREIGN KEY ( actividad_idactividad )
        REFERENCES actividad ( idactividad );

ALTER TABLE detalle_actividad
    ADD CONSTRAINT detalle_actividad_contrato_fk FOREIGN KEY ( contrato_numcontrato,
                                                               contrato_idcurso,
                                                               contrato_codcolegio,
                                                               contrato_idtipo,
                                                               contrato_rutejecutivo,
                                                               contrato_iddestino,
                                                               contrato_idtipoact,
                                                               contrato_idmod )
        REFERENCES contrato ( numcontrato,
                              curso_idcurso,
                              curso_colegio_codcolegio,
                              curso_colegio_idtipo,
                              ejecutivo_rutejecutivo,
                              destino_iddestino,
                              tipactividad_idtipoact,
                              tipactividad_modaporte_idmod );

ALTER TABLE detalle_beneficio
    ADD CONSTRAINT detalle_beneficio_beneficio_fk FOREIGN KEY ( beneficio_idbenefico )
        REFERENCES beneficio ( idbenefico );

ALTER TABLE detalle_beneficio
    ADD CONSTRAINT detalle_beneficio_contrato_fk FOREIGN KEY ( contrato_numcontrato,
                                                               contrato_idcurso,
                                                               contrato_codcolegio,
                                                               contrato_idtipo,
                                                               contrato_rutejecutivo,
                                                               contrato_iddestino,
                                                               contrato_idtipoact,
                                                               contrato_idmod )
        REFERENCES contrato ( numcontrato,
                              curso_idcurso,
                              curso_colegio_codcolegio,
                              curso_colegio_idtipo,
                              ejecutivo_rutejecutivo,
                              destino_iddestino,
                              tipactividad_idtipoact,
                              tipactividad_modaporte_idmod );

ALTER TABLE detalle_seguro
    ADD CONSTRAINT detalle_seguro_contrato_fk FOREIGN KEY ( contrato_numcontrato,
                                                            contrato_idcurso,
                                                            contrato_codcolegio,
                                                            contrato_idtipo,
                                                            contrato_rutejecutivo,
                                                            contrato_iddestino,
                                                            contrato_idtipoact,
                                                            contrato_idmod )
        REFERENCES contrato ( numcontrato,
                              curso_idcurso,
                              curso_colegio_codcolegio,
                              curso_colegio_idtipo,
                              ejecutivo_rutejecutivo,
                              destino_iddestino,
                              tipactividad_idtipoact,
                              tipactividad_modaporte_idmod );

ALTER TABLE detalle_seguro
    ADD CONSTRAINT detalle_seguro_seguro_fk FOREIGN KEY ( seguro_idseguro,
                                                          seguro_empaseg_rutemp )
        REFERENCES seguro ( idseguro,
                            empaseg_rutemp );

ALTER TABLE seguro
    ADD CONSTRAINT seguro_empaseg_fk FOREIGN KEY ( empaseg_rutemp )
        REFERENCES empaseg ( rutemp );

ALTER TABLE tipactividad
    ADD CONSTRAINT tipactividad_modaporte_fk FOREIGN KEY ( modaporte_idmod )
        REFERENCES modaporte ( idmod );
